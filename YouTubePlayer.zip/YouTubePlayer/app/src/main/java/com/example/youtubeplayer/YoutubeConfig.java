package com.example.youtubeplayer;

public class YoutubeConfig {
    public YoutubeConfig() {
    }
    private static final String apiKey="AIzaSyAREv7K2jFmoOYq7u1XsqKy0rEVgjou1BY";

    public static String getApiKey() {
        return apiKey;
    }
}
